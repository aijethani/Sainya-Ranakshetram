import os
import json
def fun(name,password):
    t = {"username":name,"password":password}
    safecode = json.dumps(t)
    with open("users.json","wb") as f:
        f.write(safecode.encode())
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)
