import os
import json
def reverse_fun():
      with open("users.json","rb") as f:
          data = f.read()
      
      t = json.loads(data)
      return t

if __name__ == '__main__':
      print(reverse_fun())
